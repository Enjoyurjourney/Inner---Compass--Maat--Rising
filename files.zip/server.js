// ═══════════════════════════════════════════════════════
//  INNER COMPASS — MA'AT RISING
//  Backend Server — Render Deployment
//  Handles: ElevenLabs TTS, Anthropic AI (Tehuti-Mila)
// ═══════════════════════════════════════════════════════

const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;

// ── MIDDLEWARE ──
app.use(cors({
  origin: '*', // Will restrict to your domain after launch
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type']
}));
app.use(express.json());

// ── HEALTH CHECK ──
app.get('/', (req, res) => {
  res.json({
    status: '🏛️ Inner Compass — Ma\'at Rising Backend is alive',
    tehuti: 'Tehuti-Mila walks beside you'
  });
});

// ═══════════════════════════════════════════════════════
//  TEHUTI-MILA VOICE ENDPOINT
//  Calls ElevenLabs API securely from the backend
//  Voice: african wisdom or Elder
//  Returns: audio/mpeg stream
// ═══════════════════════════════════════════════════════
app.post('/api/speak', async (req, res) => {
  try {
    const { text, voiceId } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }

    // Use provided voiceId or default to african wisdom
    const selectedVoiceId = voiceId || process.env.ELEVENLABS_VOICE_ID || 'vX1O2u2a6OZ6GHODWPWQ';

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${selectedVoiceId}/stream`,
      {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': process.env.ELEVENLABS_API_KEY
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_multilingual_v2',
          voice_settings: {
            stability: 0.45,        // Slightly varied — wise elder feels alive
            similarity_boost: 0.80, // Close to original voice
            style: 0.35,            // Some expressiveness — not robotic
            use_speaker_boost: true
          }
        })
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('ElevenLabs error:', error);
      return res.status(response.status).json({ error: 'Voice generation failed' });
    }

    // Stream audio back to client
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'no-cache');
    response.body.pipe(res);

  } catch (error) {
    console.error('Speak endpoint error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ═══════════════════════════════════════════════════════
//  TEHUTI-MILA AI RESPONSE ENDPOINT
//  Calls Anthropic API for intelligent responses
//  Powers: journal responses, reflections, community
// ═══════════════════════════════════════════════════════
app.post('/api/tehuti', async (req, res) => {
  try {
    const { message, userName, context } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const systemPrompt = `You are Tehuti-Mila — the sacred AI companion of Inner Compass, 
a spiritual wellness app rooted in authentic African ancestral wisdom.

Your name comes from:
- TEHUTI: The ancient Kemetic keeper of wisdom, scribe of the ancestors
- MILA: Drawn from Ọrúnmìlà, the Yoruba sage who knows the pathways of the soul

You embody three energies depending on what the user needs:
1. WISE ELDER — Ancient wisdom, ancestral knowledge, deep perspective
2. GROUNDED BROTHER/SISTAR — Warm, real, compassionate presence  
3. PRACTICAL GUIDE — Clear, actionable, solution-focused support

Always:
- Speak with warmth, depth and ancestral grounding
- Reference Ma'at, the 42 Laws, Kemetic principles when relevant
- Address the user by name when known
- Never be clinical, cold or robotic
- Meet the user exactly where they are emotionally
- Always be in the best interest of the user's growth and wellbeing

The user's name is: ${userName || 'Sacred One'}
Context: ${context || 'General conversation'}`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [
          { role: 'user', content: message }
        ]
      })
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Anthropic error:', error);
      return res.status(response.status).json({ error: 'AI response failed' });
    }

    const data = await response.json();
    const aiResponse = data.content[0].text;

    res.json({ response: aiResponse });

  } catch (error) {
    console.error('Tehuti endpoint error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ── START SERVER ──
app.listen(PORT, () => {
  console.log(`🏛️ Inner Compass Backend running on port ${PORT}`);
  console.log(`☥  Tehuti-Mila is ready to speak`);
});
